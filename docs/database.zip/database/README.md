# HS Shop database design

**Status:** proposal for review; documentation only.

## Repository baseline
- Laravel Framework `^12.0`, PHP `^8.2`; direct runtime packages are Laravel Framework and Tinker. No commerce, RBAC, payment or carrier package is declared.
- Existing migrations provide `users`, `password_reset_tokens`, `sessions`, `cache`, `cache_locks`, `jobs`, `job_batches`, and `failed_jobs`. The sole model is a basic Laravel Authenticatable `User`; the only route returns the welcome view. No store schema exists.
- Read-only inspection of `database/database.sqlite` confirms the same Laravel starter tables, plus Laravel's `migrations` bookkeeping table and SQLite's `sqlite_sequence`; it contains no shop tables. This is a SQLite development database, not the target MySQL schema.
- `.env.example` uses SQLite and database-backed sessions/cache/queue, with English locale. Target MySQL is a future deliberate configuration change. No existing database design docs were found. Preserve starter migrations/model as baseline.
- `Color_identity/` contains visual-reference HTML; it does not define data schema.

## Conventions and modules
Modular monolith: identity/access, catalog/localization, supplier sourcing, inventory, commerce, payments/fulfillment, finance, marketing/CMS, audit, Laravel infrastructure. Use InnoDB and utf8mb4. New IDs are BIGINT UNSIGNED with matching FKs; public identifiers may additionally use UUID/ULID. Instants are UTC DATETIME(6). Statuses are VARCHAR, not MySQL ENUM. Money is DECIMAL(19,4) + CHAR(3) currency; EGP default. Quantity is DECIMAL(18,3). Never use FLOAT/DOUBLE for money. Translation tables are unique per entity/locale (ar/en). Snapshot customer-facing and supplier-facing terms on documents. Master data may be archived; operational and financial history is append-only/reversed, never hard-deleted.

See [ERD](ERD.md), [table dictionary](TABLES.md), [constraints/indexes](CONSTRAINTS_AND_INDEXES.md), [workflows](WORKFLOWS.md), and [open decisions](../OPEN_DECISIONS.md). Recommendations are not approved policies. This phase creates documentation only.
