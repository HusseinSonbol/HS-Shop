# Constraints, indexes and integrity

## Referential actions
Use InnoDB FKs and RESTRICT by default. Never cascade-delete financial, order, sourcing, receipt, shipment, settlement, return/refund, cash, allocation, stock movement, approval or audit history. CASCADE is limited to disposable dependent joins/translations before publication. Archive mutable catalog/master data. SET NULL only for optional actor/catalog attribution where snapshots retain history. Existing sessions deliberately have no users FK. Correct a posted record with a linked reversal and compensating entry, not deletion.

## Unique constraints
Enforce every UNIQUE/composite key listed in [TABLES.md](TABLES.md): user email; customer user_id/number; role/permission codes and pivots; entity+locale translations; category/brand/product slugs; product/variant SKU and optional barcode; attribute code and attribute/value code; variant+attribute/value; supplier/warehouse codes; all document numbers; cart+variant and wishlist+variant; order+revision number; revision+customer approval; settlement+shipment; coupon code and coupon+order; CMS slug, settings group+key; Laravel UUIDs/references. MySQL permits multiple NULLs in unique indexes.

## Recommended supporting indexes
- users(email unique), customer_addresses(customer_id,is_default)
- products(status,published_at); variants(product_id,is_active)
- supplier_offers(variant_id,is_active,valid_until), (supplier_id,variant_id)
- sourcing_requests(status,requested_at); quotes(sourcing_request_item_id,status), (supplier_id,quoted_at)
- purchase_orders(supplier_id,status,ordered_at), (status,expected_at)
- inventory_balances unique(warehouse_id,variant_id); stock_movements(warehouse_id,variant_id,occurred_at,id), (source_type,source_id)
- stock_reservations(order_item_id,status), (warehouse_id,variant_id,status,expires_at)
- orders(customer_id,placed_at), (status,placed_at); order_items(order_id,id), (variant_id)
- approvals(decision,decided_at); payments(order_id,status); payment_transactions(payment_id,occurred_at)
- shipments(order_id,status); shipment_events(shipment_id,event_at); carrier settlements(status,period_start,period_end); settlement items(shipment_id)
- returns(order_id,status); refunds(payment_id,status)
- cash_transactions(cash_account_id,occurred_at,id), (source_type,source_id)
- cost_allocations each target FK; coupon_usages(customer_id,coupon_id,used_at)
- activity_logs(subject_type,subject_id,created_at), (actor_user_id,created_at), (correlation_id)

## Same-row checks and app-level invariants
Where target MySQL version supports CHECK, enforce nonnegative amounts/quantities where appropriate, start <= end, and accepted+rejected receipt quantities <= received quantity. DECIMAL and explicit currency rounding are mandatory.

Application validation/transactions are required for:
1. Revision total equals line/discount/shipping/tax totals; changed price/product/quantity cannot be fulfilled before explicit approval of current exact revision.
2. Product type/default variant cardinality; selected attribute values belong to the same attribute; at most one default image, variant, category/address.
3. Received total cannot exceed ordered amount without approval; PO received projection equals posted receipt lines.
4. Lock balances and prevent reservations exceeding available stock; prevent duplicate consumption/release.
5. Return quantity <= delivered minus previous returns; refunds <= eligible captured/collected funds less previous refunds.
6. Carrier settlement line/header reconciliation and no duplicate settlement; posting creates cash transaction atomically.
7. Coupon limits and address-default uniqueness under concurrency; state transitions are legal and idempotent.
8. Exactly one allocation target per row and allocation sum equals run total within rounding tolerance; prevent double allocation.
9. Order item product/variant consistency and currency consistency; preserve immutable snapshots.
10. Polymorphic ledger source references cannot have ordinary FKs; validate type/existence and prohibit source deletion.

## Concurrency and durability
Use DB transactions and SELECT FOR UPDATE (Laravel lockForUpdate) on order/revision, inventory balance/reservation, coupon, payment, receipt/PO line, settlement and cash session before conditional updates. Post ledger row and projection update atomically. Unique idempotency keys protect checkout, payment callbacks, carrier webhooks, receiving and stock postings. External calls cannot share SQL transactions: persist intent/key, call provider outside long transactions, reconcile uncertain timeout before retry. Define consistent lock order and safe deadlock retries. MySQL has no partial unique index; active-only uniqueness needs locked application logic or an approved generated-column approach.

