# HS Shop logical ERD

```mermaid
erDiagram
 USERS ||--o| CUSTOMERS : profile
 USERS ||--o{ USER_ROLE : assigned
 ROLES ||--o{ USER_ROLE : includes
 ROLES ||--o{ ROLE_PERMISSION : grants
 PERMISSIONS ||--o{ ROLE_PERMISSION : granted
 CUSTOMERS ||--o{ CUSTOMER_ADDRESSES : saves
 CATEGORIES ||--o{ CATEGORIES : parent
 PRODUCTS ||--o{ PRODUCT_CATEGORIES : categorized
 CATEGORIES ||--o{ PRODUCT_CATEGORIES : classifies
 PRODUCTS ||--o{ PRODUCT_VARIANTS : has
 PRODUCT_VARIANTS ||--o{ VARIANT_ATTRIBUTE_VALUES : configured
 ATTRIBUTES ||--o{ ATTRIBUTE_VALUES : defines
 SUPPLIERS ||--o{ SUPPLIER_OFFERS : offers
 PRODUCT_VARIANTS ||--o{ SUPPLIER_OFFERS : sourced_as
 CUSTOMERS ||--o{ ORDERS : places
 ORDERS ||--o{ ORDER_ITEMS : contains
 ORDERS ||--o{ ORDER_REVISIONS : versioned
 ORDER_REVISIONS ||--o{ CUSTOMER_APPROVALS : approved
 ORDER_ITEMS ||--o{ SOURCING_REQUEST_ITEMS : sourced
 SOURCING_REQUESTS ||--o{ SOURCING_REQUEST_ITEMS : requests
 SOURCING_REQUEST_ITEMS ||--o{ SUPPLIER_QUOTES : quoted
 SUPPLIERS ||--o{ SUPPLIER_QUOTES : responds
 SUPPLIERS ||--o{ PURCHASE_ORDERS : receives_order
 PURCHASE_ORDERS ||--o{ PURCHASE_ORDER_ITEMS : contains
 PURCHASE_ORDER_ITEMS ||--o{ GOODS_RECEIPT_ITEMS : received
 GOODS_RECEIPTS ||--o{ GOODS_RECEIPT_ITEMS : records
 WAREHOUSES ||--o{ INVENTORY_BALANCES : holds
 PRODUCT_VARIANTS ||--o{ INVENTORY_BALANCES : balances
 PRODUCT_VARIANTS ||--o{ STOCK_MOVEMENTS : moves
 ORDERS ||--o{ PAYMENTS : payable
 PAYMENTS ||--o{ PAYMENT_TRANSACTIONS : attempts
 ORDERS ||--o{ SHIPMENTS : fulfilled_by
 SHIPPING_COMPANIES ||--o{ SHIPMENTS : carries
 SHIPMENTS ||--o{ SHIPMENT_EVENTS : tracked
 SHIPMENTS ||--o{ CARRIER_SETTLEMENT_ITEMS : settled
 CARRIER_SETTLEMENTS ||--o{ CARRIER_SETTLEMENT_ITEMS : includes
 ORDERS ||--o{ RETURNS : returned
 RETURNS ||--o{ REFUNDS : refunded
 CASH_ACCOUNTS ||--o{ CASH_TRANSACTIONS : posts
 COST_ALLOCATION_RUNS ||--o{ COST_ALLOCATIONS : allocates
 EXPENSES ||--o{ COST_ALLOCATIONS : shared_cost
 COUPONS ||--o{ COUPON_USAGES : redeemed
 CUSTOMERS ||--o{ COUPON_USAGES : uses
```

- Customer profile is optional for staff, required at checkout. RBAC is many-to-many.
- Products are catalog concepts; offers, stock, and order line references resolve to variant. Simple products have one default variant; variable products have multiple.
- Supplier offers are many-to-many. Sourcing requests solicit competing quotes; purchase orders snapshot accepted quote terms and can be received in partial receipts.
- Order lines and shipping/billing addresses are immutable snapshots. Any changed price/product/quantity creates a revision requiring approval explicitly tied to that version.
- Current inventory balances are locked projections; stock movements are the immutable ledger. Reservations are distinct from physical on-hand.
- Payment, sourcing, order and shipment states remain independent. Carrier collection/settlement is separate from customer payment.
- Lifecycle: order → approval → sourcing/quotes → purchase order → receipts → reserve/ship → carrier collection/settlement → cash posting → returns/refunds → cost allocation and profitability. Owned-stock replenishment uses the same receiving/movement model.

