# Lifecycle workflows

This is behavioral design guidance, not code. State vocabularies remain application-owned and need approval.

## Account and checkout
Laravel web session authenticates users. Customer profile and active account are mandatory at checkout. Validate address, variant, quantity, price and coupon. In one transaction create order, immutable line/name/SKU/variant/price/currency snapshots, shipping/billing address snapshots and revision 1. Cart prices are not authoritative. Order state is independent of payment, sourcing and shipment states.

## Changed order and explicit approval
Any changed price, product or quantity creates a new full-snapshot order revision. Do not rewrite the approved revision. Record customer decision, channel, time and evidence against that exact revision. Current revision cannot be fulfilled/captured until approved. Serialize revision numbers by locking order. Rejection/expiry must follow an explicit policy; silence is not approval.

## Sourcing and receipts
Create sourcing requests for uncovered order demand or independent replenishment. Capture competing supplier quotes with supplier, quantity, currency, cost, validity, lead time and delivery. Accepted terms are copied to PO header/lines. Receive against PO in multiple goods receipts. In a transaction lock PO line and inventory balance, validate remainder, record receipt line and stock movement, update balance and received projection. Idempotently post. Supplier return reverses eligible accepted quantity with movement and remains separately recorded.

## Inventory
Opening stock, receipt, transfer, reservation, fulfillment, count adjustment, customer return and supplier return are distinct movement types. Stock movement is immutable signed ledger; balance is a locked projection. Reservations affect reserved quantity, not physical on-hand. Reserve only available stock and release/consume once. Adjustments require reason and any required approval. Transfers use paired movements and a transfer document if later introduced.

## Payments
Keep payment record and immutable attempts/transactions. Auth, capture, refund are distinct types; store sanitized provider metadata only, never card security data. Verify callbacks, deduplicate provider event/idempotency key, lock payment/order and validate amount/currency. Payment state never implicitly changes other module states. Reconcile gateway settlement/fees separately if required. External call stays outside long DB transaction.

## Shipping and carrier settlement
Allow multiple shipments and partial shipment items; snapshot recipient/COD due. Manual status changes append shipment events; future integration normalizes webhook events and keeps sanitized payload/provider ID. Deduplicate callbacks. Track actual collection separately from expected COD. Carrier settlement header and per-shipment lines capture remittance, fees and discrepancy. Posting net cash creates linked cash transaction atomically.

## Return and refund
Return request/items reference ordered quantities. On inspection record condition/disposition/restock eligibility. Enforce returns <= delivered less prior returns. Restock only via stock movement after inspection. Refund is separate and linked to return/order/payment, bounded by eligible amount; COD may require manual cash payout. Retain rejected/partial cases.

## Cash, expenses and profitability
Cash transactions are append-only in/out entries. Cash sessions record opening, expected and counted closing and variance; adjustments use new transaction. Expenses retain source and can be allocated through immutable allocation runs; reversing runs correct errors, with deterministic rounding remainder. Profit reports should distinguish booked revenue from collections and include landed cost, allocated procurement cost, discounts, carrier fees, refunds/returns; show unallocated overhead separately.

## Transaction boundaries
Transactions cover checkout, revision/approval transition, coupon redemption, receipt/adjustment/reservation/consumption/release, payment event posting, carrier settlement, return/refund, cash close and allocation posting. Lock aggregate and projection rows, use idempotency tokens, and keep network operations out of SQL transactions.

