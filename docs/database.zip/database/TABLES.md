# Proposed table dictionary

All tables use InnoDB/utf8mb4. Unless noted, primary key is BIGINT UNSIGNED `id`, timestamps are DATETIME(6). FKs match referenced types. Money = DECIMAL(19,4) with CHAR(3) currency, quantity = DECIMAL(18,3); no FLOAT/DOUBLE. Status fields are VARCHAR state vocabularies. Below are all proposed logical columns; audit/ledger rows are append-only.

## Identity and access
- **users** (extend existing): id PK, name VARCHAR(160), email VARCHAR(190) UNIQUE, email_verified_at DATETIME(6) NULL, password VARCHAR(255), phone VARCHAR(32) NULL, preferred_locale VARCHAR(10) DEFAULT ar, is_active TINYINT(1), remember_token VARCHAR(100) NULL, created_at/updated_at, deleted_at NULL. Existing migration has name/email/email_verified_at/password/remember_token/timestamps.
- **customers**: id, user_id FK UNIQUE, customer_number VARCHAR(40) UNIQUE, marketing_consent_at NULL, notes TEXT NULL, timestamps.
- **roles**: id, code VARCHAR(80) UNIQUE, name VARCHAR(120), is_system TINYINT(1), timestamps. **permissions**: id, code VARCHAR(120) UNIQUE, description VARCHAR(255) NULL, timestamps.
- **user_role**: user_id FK, role_id FK, assigned_by FK users NULL, created_at; composite PK(user_id,role_id). **role_permission**: role_id FK, permission_id FK; composite PK(role_id,permission_id).
- **customer_addresses**: id, customer_id FK, label VARCHAR(80) NULL, recipient_name VARCHAR(160), phone VARCHAR(32), country_code CHAR(2), governorate/city VARCHAR(120), district VARCHAR(120) NULL, street VARCHAR(255), building/floor/apartment VARCHAR(80) NULL, landmark VARCHAR(255) NULL, postal_code VARCHAR(20) NULL, latitude/longitude DECIMAL(10,7) NULL, is_default TINYINT(1), timestamps, deleted_at NULL.

## Catalog and translations
- **categories**: id, parent_id self-FK NULL, slug VARCHAR(190) UNIQUE, sort_order INT, is_active, deleted_at, timestamps. **category_translations**: id, category_id FK, locale VARCHAR(10), name VARCHAR(190), description TEXT NULL, UNIQUE(category_id,locale).
- **brands**: id, slug VARCHAR(190) UNIQUE, logo_path VARCHAR(500) NULL, is_active, deleted_at, timestamps. **brand_translations**: id, brand_id FK, locale, name, description NULL, UNIQUE(brand_id,locale).
- **products**: id, brand_id FK NULL, product_type VARCHAR(20) simple/variable, sku VARCHAR(80) UNIQUE, slug VARCHAR(190) UNIQUE, status VARCHAR(24), requires_shipping TINYINT(1), tax_class VARCHAR(80) NULL, weight_g INT UNSIGNED NULL, published_at NULL, deleted_at, timestamps. **product_translations**: id, product_id FK, locale, name VARCHAR(220), short_description VARCHAR(500) NULL, description LONGTEXT NULL, meta_title VARCHAR(220) NULL, meta_description VARCHAR(500) NULL, UNIQUE(product_id,locale).
- **product_categories**: product_id/category_id FKs, is_primary TINYINT(1), composite PK. **product_variants**: id, product_id FK, sku VARCHAR(80) UNIQUE, barcode VARCHAR(80) NULL UNIQUE, variant_name VARCHAR(220) NULL, is_default/is_active TINYINT(1), weight_g INT UNSIGNED NULL, deleted_at, timestamps.
- **attributes**: id, code VARCHAR(80) UNIQUE, input_type VARCHAR(24), is_variant_axis TINYINT(1), sort_order INT, timestamps. **attribute_translations**: id, attribute_id FK, locale, name VARCHAR(120), UNIQUE(attribute_id,locale).
- **attribute_values**: id, attribute_id FK, code VARCHAR(100), sort_order INT, UNIQUE(attribute_id,code). **attribute_value_translations**: id, attribute_value_id FK, locale, value VARCHAR(160), UNIQUE(attribute_value_id,locale).
- **variant_attribute_values**: variant_id/attribute_id/attribute_value_id FKs, composite PK(variant_id,attribute_id), UNIQUE(variant_id,attribute_value_id). **product_images**: id, product_id FK, variant_id FK NULL, path VARCHAR(500), alt_text VARCHAR(255) NULL, sort_order INT, is_primary TINYINT(1), timestamps.

## Suppliers and sourcing
- **suppliers**: id, code VARCHAR(60) UNIQUE, name VARCHAR(190), contact_name VARCHAR(160) NULL, email VARCHAR(190) NULL, phone VARCHAR(32) NULL, address_json JSON NULL, default_currency CHAR(3), payment_terms VARCHAR(120) NULL, is_active, timestamps, deleted_at.
- **supplier_offers**: id, supplier_id/variant_id FKs, supplier_sku VARCHAR(100) NULL, unit_cost DECIMAL(19,4), currency CHAR(3), minimum_order_qty DECIMAL(18,3), lead_time_days SMALLINT UNSIGNED NULL, available_qty DECIMAL(18,3) NULL, valid_from/valid_until DATETIME(6) NULL, is_active, timestamps. Multiple suppliers per variant; retain offer history.
- **sourcing_requests**: id, request_number VARCHAR(40) UNIQUE, order_id FK NULL (replenishment), status VARCHAR(24), requested_by FK users, requested_at DATETIME(6), due_at NULL, notes TEXT NULL, timestamps.
- **sourcing_request_items**: id, sourcing_request_id FK, order_item_id FK NULL, variant_id FK, requested_qty DECIMAL(18,3), target_unit_cost DECIMAL(19,4) NULL, currency CHAR(3), status, timestamps.
- **supplier_quotes**: id, sourcing_request_item_id/supplier_id FKs, supplier_offer_id FK NULL, quoted_qty DECIMAL(18,3), unit_cost DECIMAL(19,4), currency CHAR(3), shipping_cost DECIMAL(19,4), valid_until NULL, lead_time_days SMALLINT UNSIGNED NULL, status VARCHAR(24), quoted_at DATETIME(6), notes TEXT NULL, timestamps.
- **purchase_orders**: id, po_number VARCHAR(40) UNIQUE, supplier_id FK, sourcing_request_id FK NULL, status, currency, subtotal/shipping_cost/discount_amount/tax_amount/total DECIMAL(19,4), supplier_snapshot JSON, ordered_at/expected_at NULL, created_by FK users, timestamps, cancelled_at NULL.
- **purchase_order_items**: id, purchase_order_id FK, quote_id FK NULL, variant_id FK, sku_snapshot VARCHAR(80), product_name_snapshot VARCHAR(220), variant_snapshot JSON NULL, ordered_qty/received_qty DECIMAL(18,3), unit_cost/line_total DECIMAL(19,4), currency CHAR(3), timestamps.
- **goods_receipts**: id, receipt_number VARCHAR(40) UNIQUE, purchase_order_id FK, warehouse_id FK, status, received_at DATETIME(6), received_by FK users, supplier_document_number VARCHAR(100) NULL, notes TEXT NULL, timestamps.
- **goods_receipt_items**: id, goods_receipt_id/purchase_order_item_id/variant_id FKs, received_qty/accepted_qty/rejected_qty DECIMAL(18,3), unit_cost DECIMAL(19,4), condition VARCHAR(24), timestamps.
- **supplier_returns**: id, return_number VARCHAR(40) UNIQUE, supplier_id FK, purchase_order_id/goods_receipt_id FK NULL, status, currency, total_amount DECIMAL(19,4), reason TEXT, sent_at NULL, created_by FK users, timestamps.
- **supplier_return_items**: id, supplier_return_id FK, goods_receipt_item_id FK NULL, variant_id FK, quantity DECIMAL(18,3), unit_cost/line_total DECIMAL(19,4), timestamps.

## Inventory
- **warehouses**: id, code VARCHAR(60) UNIQUE, name VARCHAR(160), address_json JSON NULL, is_active, timestamps, deleted_at.
- **inventory_balances**: id, warehouse_id/variant_id FKs, on_hand_qty/reserved_qty DECIMAL(18,3), updated_at, UNIQUE(warehouse_id,variant_id). Available = on-hand minus reserved.
- **stock_movements**: id, movement_number CHAR(36) UNIQUE, warehouse_id/variant_id FKs, movement_type VARCHAR(32), quantity_delta DECIMAL(18,3) signed, unit_cost DECIMAL(19,4) NULL, currency CHAR(3) NULL, source_type VARCHAR(50), source_id BIGINT UNSIGNED, occurred_at DATETIME(6), created_by FK users NULL, reversal_of_id self-FK NULL, notes TEXT NULL, created_at.
- **stock_reservations**: id, order_item_id/warehouse_id/variant_id FKs, quantity DECIMAL(18,3), status VARCHAR(20), expires_at/released_at NULL, created_at.
- **inventory_adjustments**: id, adjustment_number VARCHAR(40) UNIQUE, warehouse_id FK, status, reason VARCHAR(120), notes TEXT NULL, created_by/approved_by FK users, approved_at NULL, timestamps.
- **inventory_adjustment_items**: id, inventory_adjustment_id/variant_id FKs, system_qty/counted_qty/delta_qty DECIMAL(18,3), unit_cost DECIMAL(19,4) NULL, timestamps. Posting produces movement.

## Commerce
- **carts**: id, customer_id FK, status, currency CHAR(3), expires_at NULL, timestamps. **cart_items**: id, cart_id/variant_id FKs, quantity DECIMAL(18,3), added_at/updated_at, UNIQUE(cart_id,variant_id); cart price is non-authoritative.
- **wishlists**: id, customer_id FK, name VARCHAR(120), is_default, timestamps. **wishlist_items**: id, wishlist_id/variant_id FKs, created_at, UNIQUE(wishlist_id,variant_id).
- **orders**: id, order_number VARCHAR(40) UNIQUE, customer_id FK, status VARCHAR(24), currency CHAR(3) DEFAULT EGP, subtotal/discount_total/shipping_total/tax_total/grand_total DECIMAL(19,4), current_revision_no INT UNSIGNED, customer_note TEXT NULL, placed_at DATETIME(6), cancelled_at NULL, timestamps. Payment/sourcing/shipment state is separate.
- **order_items**: id, order_id FK, product_id/variant_id FK NULL, sku_snapshot VARCHAR(80), product_name_snapshot VARCHAR(220), variant_snapshot JSON NULL, quantity DECIMAL(18,3), unit_price/discount_amount/tax_amount/line_total DECIMAL(19,4), currency CHAR(3), created_at.
- **order_address_snapshots**: id, order_id FK, address_type VARCHAR(12), recipient_name VARCHAR(160), phone VARCHAR(32), country_code CHAR(2), governorate/city VARCHAR(120), district NULL, street VARCHAR(255), building/floor/apartment VARCHAR(80) NULL, landmark VARCHAR(255) NULL, postal_code VARCHAR(20) NULL, created_at, UNIQUE(order_id,address_type).
- **order_revisions**: id, order_id FK, revision_no INT UNSIGNED, revision_type VARCHAR(24), change_summary TEXT, snapshot JSON, total DECIMAL(19,4), currency CHAR(3), proposed_by FK users, proposed_at DATETIME(6), approval_required TINYINT(1), UNIQUE(order_id,revision_no).
- **customer_approvals**: id, order_revision_id/customer_id FKs, decision VARCHAR(16), decided_at DATETIME(6), channel VARCHAR(24), evidence JSON NULL, created_at, UNIQUE(order_revision_id,customer_id). Every changed price/product/quantity must be approved on that exact revision.

## Payments, shipping and finance
- **payments**: id, order_id FK, payment_number VARCHAR(40) UNIQUE, method VARCHAR(32), status VARCHAR(24), amount DECIMAL(19,4), currency CHAR(3), provider VARCHAR(80) NULL, timestamps.
- **payment_transactions**: id, payment_id FK, transaction_uuid CHAR(36) UNIQUE, transaction_type/status VARCHAR(24), amount DECIMAL(19,4), currency CHAR(3), provider_reference VARCHAR(190) NULL, idempotency_key VARCHAR(120) NULL UNIQUE, request_payload/response_payload JSON NULL, occurred_at DATETIME(6), created_at.
- **shipping_companies**: id, code VARCHAR(60) UNIQUE, name VARCHAR(160), integration_driver VARCHAR(80) NULL, config JSON NULL (secrets encrypted/external), is_active, timestamps.
- **shipments**: id, shipment_number VARCHAR(40) UNIQUE, order_id/shipping_company_id FKs (company nullable), status, tracking_number VARCHAR(120) NULL, shipping_cost/cod_amount DECIMAL(19,4), currency CHAR(3), shipped_at/delivered_at NULL, recipient_snapshot JSON, created_by FK users NULL, timestamps. **shipment_items**: id, shipment_id/order_item_id FKs, quantity DECIMAL(18,3), UNIQUE(shipment_id,order_item_id).
- **shipment_events**: id, shipment_id FK, status, event_at DATETIME(6), description VARCHAR(500) NULL, location VARCHAR(190) NULL, source VARCHAR(24), provider_event_id VARCHAR(190) NULL, payload JSON NULL, created_at.
- **carrier_settlements**: id, settlement_number VARCHAR(40) UNIQUE, shipping_company_id FK NULL, status, currency, gross_collected/carrier_fees/other_deductions/net_due/paid_amount DECIMAL(19,4), statement_reference VARCHAR(120) NULL, period_start/period_end DATE NULL, received_at NULL, created_by FK users, timestamps.
- **carrier_settlement_items**: id, carrier_settlement_id/shipment_id FKs, expected_collection/collected_amount/fee_amount/difference_amount DECIMAL(19,4), cash_transaction_id FK NULL, notes TEXT NULL, UNIQUE(carrier_settlement_id,shipment_id).
- **returns**: id, return_number VARCHAR(40) UNIQUE, order_id/customer_id FKs, status, reason VARCHAR(120), requested_at DATETIME(6), received_at NULL, resolution VARCHAR(24) NULL, notes TEXT NULL, timestamps. **return_items**: id, return_id/order_item_id FKs, quantity DECIMAL(18,3), condition VARCHAR(24) NULL, restock TINYINT(1), refund_amount DECIMAL(19,4), timestamps.
- **refunds**: id, refund_number VARCHAR(40) UNIQUE, return_id/payment_id FK NULL, order_id FK, status, amount DECIMAL(19,4), currency CHAR(3), reason VARCHAR(255) NULL, refunded_at NULL, created_by FK users, timestamps.
- **expenses**: id, expense_number VARCHAR(40) UNIQUE, category VARCHAR(80), description VARCHAR(255), amount DECIMAL(19,4), currency CHAR(3), expense_date DATE, supplier_id FK NULL, cash_transaction_id FK NULL, allocation_method VARCHAR(24) NULL, status, created_by FK users, timestamps.
- **cash_accounts**: id, code VARCHAR(60) UNIQUE, name VARCHAR(160), account_type VARCHAR(24), currency CHAR(3), is_active, timestamps.
- **cash_sessions**: id, cash_account_id/opened_by/closed_by FKs (closer nullable), opening_balance/closing_count/expected_balance DECIMAL(19,4), opened_at DATETIME(6), closed_at NULL, notes TEXT NULL.
- **cash_transactions**: id, cash_account_id/cash_session_id FKs (session nullable), transaction_number VARCHAR(40) UNIQUE, direction VARCHAR(8), transaction_type VARCHAR(32), amount DECIMAL(19,4), currency CHAR(3), source_type VARCHAR(50) NULL, source_id BIGINT UNSIGNED NULL, occurred_at DATETIME(6), created_by FK users, reversal_of_id self-FK NULL, description VARCHAR(255) NULL, created_at. Append-only.
- **cost_allocation_runs**: id, run_number VARCHAR(40) UNIQUE, status, source_expense_id FK NULL, basis VARCHAR(24), currency, total_amount DECIMAL(19,4), run_at DATETIME(6), created_by FK users, reverses_run_id self-FK NULL, notes TEXT NULL, timestamps.
- **cost_allocations**: id, cost_allocation_run_id FK, purchase_order_item_id/goods_receipt_item_id/order_item_id FKs nullable, amount DECIMAL(19,4), currency CHAR(3), basis_value DECIMAL(19,4) NULL, created_at. Exactly one target enforced in app.

## Marketing, content and audit
- **coupons**: id, code VARCHAR(80) UNIQUE, discount_type VARCHAR(16), discount_value DECIMAL(19,4), currency CHAR(3) NULL, minimum_order_amount/maximum_discount DECIMAL(19,4) NULL, usage_limit/per_customer_limit INT UNSIGNED NULL, starts_at/ends_at NULL, is_active, timestamps.
- **coupon_usages**: id, coupon_id/customer_id/order_id FKs, discount_amount DECIMAL(19,4), currency CHAR(3), used_at DATETIME(6), UNIQUE(coupon_id,order_id).
- **banners**: id, placement VARCHAR(80), image_path VARCHAR(500), target_url VARCHAR(500) NULL, sort_order INT, starts_at/ends_at NULL, is_active, timestamps. **banner_translations**: id, banner_id FK, locale, title/alt_text VARCHAR(255) NULL, UNIQUE(banner_id,locale).
- **cms_pages**: id, slug VARCHAR(190) UNIQUE, status, published_at NULL, created_by/updated_by FKs users, timestamps. **cms_page_translations**: id, cms_page_id FK, locale, title VARCHAR(220), body LONGTEXT, meta_title VARCHAR(220) NULL, meta_description VARCHAR(500) NULL, UNIQUE(cms_page_id,locale).
- **settings**: id, group VARCHAR(80), key VARCHAR(120), value JSON, is_public TINYINT(1), timestamps, UNIQUE(group,key); never plaintext secrets.
- **activity_logs**: id, actor_user_id FK NULL, event VARCHAR(120), subject_type VARCHAR(80), subject_id BIGINT UNSIGNED, before/after JSON NULL, ip_address VARCHAR(45) NULL, user_agent VARCHAR(500) NULL, correlation_id CHAR(36) NULL, created_at. Immutable, redact secrets/needless personal data.

## Laravel infrastructure (preserve existing)
- **password_reset_tokens**: email VARCHAR(255) PK, token VARCHAR(255), created_at TIMESTAMP NULL.
- **sessions**: id VARCHAR(255) PK, user_id BIGINT UNSIGNED NULL indexed (no FK by current migration), ip_address VARCHAR(45) NULL, user_agent TEXT NULL, payload LONGTEXT, last_activity INT indexed.
- **cache/cache_locks**: key VARCHAR(255) PK, value MEDIUMTEXT / owner VARCHAR(255), expiration INT indexed.
- **jobs**: id BIGINT UNSIGNED PK, queue indexed, payload LONGTEXT, attempts TINYINT UNSIGNED, reserved_at/available_at/created_at INT. **job_batches**: id VARCHAR(255) PK, name, job counts, failed_job_ids, options nullable, cancelled_at/created_at/finished_at. **failed_jobs**: id BIGINT UNSIGNED PK, uuid UNIQUE, connection, queue, payload, exception, failed_at.
- If database notifications are selected later: Laravel notifications table with UUID PK, type, notifiable_type/notifiable_id, data, read_at, created_at; index(notifiable_type,notifiable_id).

